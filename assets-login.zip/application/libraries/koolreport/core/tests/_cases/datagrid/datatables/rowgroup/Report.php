<?php

require_once "../../../DbReport.php";

class Report extends DbReport
{

}