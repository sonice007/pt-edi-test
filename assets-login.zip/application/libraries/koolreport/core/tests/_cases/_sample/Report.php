<?php

class Report extends \koolreport\KoolReport
{

}